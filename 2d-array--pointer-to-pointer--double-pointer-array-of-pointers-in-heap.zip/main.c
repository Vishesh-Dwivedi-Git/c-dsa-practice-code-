/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.
2d array- pointer to pointer -double pointer-array of pointers in heap 

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
int main()
{
    int **A;
    A=(int**)malloc(3*sizeof(int*)); // in c++ -- A=new int*[3];
    A[0]=(int*)malloc(4*sizeof(int));
    A[1]=(int*)malloc(4*sizeof(int));
    A[2]=(int*)malloc(4*sizeof(int));
    printf("enter the elments:");
    for(int i=0;i<3;i++){
        for(int j=0;j<4;j++){
            scanf("%d",&A[i][j]);
        }
    }
    for(int i=0;i<3;i++){
        for(int j=0;j<4;j++){
            printf("%d\t",A[i][j]);
        }
        printf("\n");
    }

    return 0;
}
